import os
from dotenv import load_dotenv

load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID   = os.getenv("TELEGRAM_CHAT_ID")
ANTHROPIC_API_KEY  = ""  # не нужен в бесплатной версии

# Минимальный скор для попадания в дайджест (0–10)
# Поставь 4.0 чтобы получать почти всё, 6.0 для фильтрации
MIN_SCORE = float(os.getenv("MIN_SCORE", "4.0"))

# Время дайджеста UTC (HH:MM). Москва = UTC+3, т.е. 09:00 МСК = 06:00 UTC
DIGEST_TIME = os.getenv("DIGEST_TIME", "06:00")
