import sqlite3
import os
import logging

logger = logging.getLogger(__name__)


class Database:
    def __init__(self, db_path: str = "data/startups.db"):
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db_path = db_path
        self._init()

    def _init(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS seen (
                    id      TEXT PRIMARY KEY,
                    title   TEXT,
                    url     TEXT,
                    source  TEXT,
                    score   REAL DEFAULT 0,
                    seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.commit()

    def is_seen(self, item_id: str) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT 1 FROM seen WHERE id = ?", (item_id,)
            ).fetchone()
            return row is not None

    def mark_seen(self, item_id: str, title: str, url: str,
                  source: str, score: float = 0.0):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT OR IGNORE INTO seen (id, title, url, source, score) "
                "VALUES (?, ?, ?, ?, ?)",
                (item_id, title, url, source, score),
            )
            conn.commit()
