import asyncio
import httpx
import logging
from typing import List, Dict

logger = logging.getLogger(__name__)

BASE = "https://hacker-news.firebaseio.com/v0"


async def fetch_show_hn() -> List[Dict]:
    """Fetch top Show HN posts — where startups announce themselves."""
    async with httpx.AsyncClient(timeout=30) as client:
        # Show HN stories
        resp = await client.get(f"{BASE}/showstories.json")
        story_ids = resp.json()[:60]

        tasks = [_fetch_story(client, sid) for sid in story_ids]
        stories = await asyncio.gather(*tasks, return_exceptions=True)

    items = []
    for story in stories:
        if isinstance(story, Exception) or story is None:
            continue
        title = story.get("title", "")
        # Only "Show HN:" posts
        if not title.lower().startswith("show hn"):
            continue
        items.append({
            "id":          f"hn_{story['id']}",
            "title":       title,
            "url":         story.get("url") or f"https://news.ycombinator.com/item?id={story['id']}",
            "source":      "Hacker News",
            "description": story.get("text", "")[:600],
            "upvotes":     story.get("score", 0),
            "comments":    story.get("descendants", 0),
        })

    logger.info(f"HN: fetched {len(items)} Show HN posts")
    return items


async def _fetch_story(client: httpx.AsyncClient, sid: int) -> Dict | None:
    try:
        resp = await client.get(f"{BASE}/item/{sid}.json")
        return resp.json()
    except Exception:
        return None
