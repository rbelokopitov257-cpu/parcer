import asyncio
import logging
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, ANTHROPIC_API_KEY, MIN_SCORE, DIGEST_TIME
from database import Database
from analyzer_free import analyze_startup  # бесплатная версия без Claude API
from notifier import send_digest
from scrapers import fetch_show_hn, fetch_product_hunt, fetch_techcrunch, fetch_reddit

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

db = Database()

SCRAPERS = [
    ("Hacker News",  fetch_show_hn),
    ("Product Hunt", fetch_product_hunt),
    ("TechCrunch",   fetch_techcrunch),
    ("Reddit",       fetch_reddit),
]


async def run_agent():
    logger.info("=" * 50)
    logger.info("🔍  Starting daily startup scan")
    logger.info("=" * 50)

    # ── 1. Collect ──────────────────────────────────────
    all_items = []
    for name, scraper in SCRAPERS:
        try:
            items = await scraper()
            logger.info(f"  ✅ {name}: {len(items)} items")
            all_items.extend(items)
        except Exception as e:
            logger.error(f"  ❌ {name}: {e}")

    # ── 2. Deduplicate ───────────────────────────────────
    new_items = [i for i in all_items if not db.is_seen(i["id"])]
    logger.info(f"\n📦  {len(new_items)} new (of {len(all_items)} total)\n")

    # ── 3. Analyze (free heuristic) ──────────────────────
    scored = []
    for item in new_items:
        analysis = await analyze_startup(item)
        score = analysis.get("score", 0) if analysis else 0

        db.mark_seen(item["id"], item["title"], item["url"], item["source"], score)

        if analysis and score >= MIN_SCORE:
            item["analysis"] = analysis
            scored.append(item)

    scored.sort(key=lambda x: x["analysis"]["score"], reverse=True)

    logger.info(f"\n📬  Sending {len(scored)} startups to Telegram …")

    # ── 4. Send digest ───────────────────────────────────
    await send_digest(TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, scored)
    logger.info("✅  Done!\n")


async def main():
    hour, minute = map(int, DIGEST_TIME.split(":"))

    scheduler = AsyncIOScheduler(timezone="UTC")
    scheduler.add_job(run_agent, "cron", hour=hour, minute=minute,
                      id="daily_digest", replace_existing=True)
    scheduler.start()

    logger.info(f"🤖  Startup Agent running — daily digest at {DIGEST_TIME} UTC")
    logger.info(f"📊  Min score threshold: {MIN_SCORE}")

    # Run once immediately on startup
    await run_agent()

    try:
        while True:
            await asyncio.sleep(3600)
    except (KeyboardInterrupt, SystemExit):
        scheduler.shutdown()
        logger.info("Stopped.")


if __name__ == "__main__":
    asyncio.run(main())
