import httpx
import logging
from typing import List, Dict

logger = logging.getLogger(__name__)

SUBREDDITS = [
    ("startups",            100),
    ("entrepreneur",        200),
    ("SideProject",         100),
    ("InternetIsBeautiful", 500),
    ("YCombinator",          50),
]

HEADERS = {"User-Agent": "startup-agent/1.0 (daily digest bot)"}


async def fetch_reddit() -> List[Dict]:
    """Fetch hot posts from startup-focused subreddits."""
    items = []

    async with httpx.AsyncClient(timeout=30, headers=HEADERS) as client:
        for sub, min_score in SUBREDDITS:
            try:
                resp = await client.get(
                    f"https://www.reddit.com/r/{sub}/hot.json",
                    params={"limit": 25},
                )
                resp.raise_for_status()
                posts = resp.json().get("data", {}).get("children", [])
            except Exception as e:
                logger.error(f"Reddit r/{sub} failed: {e}")
                continue

            for post in posts:
                p = post.get("data", {})
                if p.get("score", 0) < min_score:
                    continue
                if p.get("is_self") and len(p.get("selftext", "")) < 50:
                    continue  # skip empty self-posts

                items.append({
                    "id":          f"reddit_{p['id']}",
                    "title":       p.get("title", "").strip(),
                    "url":         _best_url(p),
                    "source":      f"Reddit r/{sub}",
                    "description": p.get("selftext", "")[:600],
                    "upvotes":     p.get("score", 0),
                    "comments":    p.get("num_comments", 0),
                })

    logger.info(f"Reddit: fetched {len(items)} posts")
    return items


def _best_url(p: dict) -> str:
    """Prefer external URL, fall back to Reddit thread."""
    url = p.get("url", "")
    if url and "reddit.com" not in url:
        return url
    return f"https://www.reddit.com{p.get('permalink', '')}"
