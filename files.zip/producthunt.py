import httpx
import feedparser
import logging
from typing import List, Dict

logger = logging.getLogger(__name__)

PH_RSS = "https://www.producthunt.com/feed"


async def fetch_product_hunt() -> List[Dict]:
    """Fetch today's top products from Product Hunt RSS."""
    async with httpx.AsyncClient(timeout=30, follow_redirects=True) as client:
        try:
            resp = await client.get(PH_RSS, headers={"User-Agent": "startup-agent/1.0"})
            resp.raise_for_status()
        except Exception as e:
            logger.error(f"Product Hunt fetch failed: {e}")
            return []

    feed = feedparser.parse(resp.text)
    items = []

    for entry in feed.entries[:25]:
        link = entry.get("link", "")
        items.append({
            "id":          f"ph_{_slug(link)}",
            "title":       entry.get("title", "").strip(),
            "url":         link,
            "source":      "Product Hunt",
            "description": _strip_html(entry.get("summary", ""))[:600],
            "upvotes":     0,
            "comments":    0,
        })

    logger.info(f"Product Hunt: fetched {len(items)} products")
    return items


def _slug(url: str) -> str:
    return url.rstrip("/").split("/")[-1] or url[-40:]


def _strip_html(text: str) -> str:
    import re
    return re.sub(r"<[^>]+>", "", text).strip()
