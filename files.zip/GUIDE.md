# 🚀 Startup Agent — бесплатная версия

**Полностью бесплатно. Нужны только два токена Telegram.**

---

## Что делает

Каждый день в нужное время парсит 4 источника:
- Hacker News (Show HN — там стартапы анонсируют себя)
- Product Hunt (новые продукты дня)
- TechCrunch (статьи про стартапы)
- Reddit (r/startups, r/entrepreneur, r/SideProject, r/YCombinator)

И присылает одним сообщением всё новое что нашёл.

---

## Шаг 1 — Создай Telegram-бота (3 минуты)

1. Открой Telegram, найди **@BotFather**
2. Напиши `/newbot`
3. Придумай имя: например `Startup Digest`
4. Придумай username: например `my_startup_digest_bot`
5. Получишь токен вида `1234567890:ABCdefGHI...` → сохрани

6. Узнай свой chat_id:
   - Найди **@userinfobot** в Telegram
   - Напиши `/start`
   - Он пришлёт твой ID, например `987654321` → сохрани

7. Напиши своему новому боту `/start` — обязательно, иначе он не сможет слать тебе сообщения

---

## Шаг 2 — Задеплой на Railway (бесплатный хостинг)

### 2.1 Загрузи файлы на GitHub

1. Зайди на https://github.com → нажми "+" → New repository
2. Назови `startup-agent`, нажми Create repository
3. Нажми "uploading an existing file"
4. Перетащи ВСЕ файлы из этой папки (включая папку `scrapers/`)
5. Нажми Commit changes

### 2.2 Деплой

1. Зайди на https://railway.app
2. Войди через GitHub (бесплатно)
3. Нажми **New Project → Deploy from GitHub repo**
4. Выбери репозиторий `startup-agent`
5. Railway сам найдёт Dockerfile и начнёт сборку (~2 минуты)

### 2.3 Добавь переменные

В Railway: открой проект → Variables → Add Variable

```
TELEGRAM_BOT_TOKEN = 1234567890:ABCdef...
TELEGRAM_CHAT_ID   = 987654321
DIGEST_TIME        = 06:00
MIN_SCORE          = 4.0
```

> DIGEST_TIME в UTC. Москва = UTC+3.
> Хочешь в 9:00 МСК → ставь 06:00

После добавления переменных Railway автоматически перезапустит контейнер.
Агент сразу пришлёт первый дайджест, затем будет слать каждый день.

---

## Альтернатива: запуск на своём компьютере

Нужен Docker Desktop: https://docker.com/products/docker-desktop

```bash
# 1. Создай .env файл из примера
cp .env.example .env

# 2. Открой .env и вставь свои токены
# (любым текстовым редактором)

# 3. Запусти
docker compose up -d

# Смотри логи
docker compose logs -f
```

> Минус: компьютер должен быть включён в момент отправки дайджеста

---

## Как выглядит сообщение

```
🚀 Стартап-дайджест 14 Mar 2025 — 15 новых

🔥 Windsurf IDE — Dev Tools
AI-редактор кода с автодополнением на базе LLM
Поднял $35M Series B, 500k пользователей за 3 месяца
🔗 https://windsurf.ai

⭐ Pika Labs — AI
Генерация видео из текста за секунды
Завирусился в Twitter — 300+ upvotes на HN
🔗 https://pika.art

📌 Supabase — Dev Tools
Open-source альтернатива Firebase
Активное обсуждение в tech-сообществе
🔗 https://supabase.com
```

---

## Настройки

| Переменная | Что делает |
|---|---|
| `DIGEST_TIME` | Время отправки в UTC (06:00 = 9:00 МСК) |
| `MIN_SCORE` | Порог фильтрации. 4.0 = почти всё, 6.0 = только заметные |
