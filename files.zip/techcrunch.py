import httpx
import feedparser
import re
import logging
from typing import List, Dict

logger = logging.getLogger(__name__)

FEEDS = [
    "https://techcrunch.com/category/startups/feed/",
    "https://techcrunch.com/tag/funding/feed/",
]


async def fetch_techcrunch() -> List[Dict]:
    """Fetch startup and funding articles from TechCrunch RSS."""
    items = []
    seen_urls = set()

    async with httpx.AsyncClient(timeout=30, follow_redirects=True) as client:
        for feed_url in FEEDS:
            try:
                resp = await client.get(
                    feed_url, headers={"User-Agent": "startup-agent/1.0"}
                )
                resp.raise_for_status()
            except Exception as e:
                logger.error(f"TechCrunch feed {feed_url} failed: {e}")
                continue

            feed = feedparser.parse(resp.text)
            for entry in feed.entries[:15]:
                url = entry.get("link", "")
                if url in seen_urls:
                    continue
                seen_urls.add(url)

                items.append({
                    "id":          f"tc_{_id_from_url(url)}",
                    "title":       entry.get("title", "").strip(),
                    "url":         url,
                    "source":      "TechCrunch",
                    "description": _strip_html(entry.get("summary", ""))[:600],
                    "upvotes":     0,
                    "comments":    0,
                })

    logger.info(f"TechCrunch: fetched {len(items)} articles")
    return items


def _id_from_url(url: str) -> str:
    return url.rstrip("/").split("/")[-1][-50:]


def _strip_html(text: str) -> str:
    return re.sub(r"<[^>]+>", "", text).strip()
