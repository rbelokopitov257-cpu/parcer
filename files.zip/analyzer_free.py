"""
Бесплатная версия анализатора — без Claude API.
Использует эвристику: ключевые слова + upvotes + источник.

Чтобы использовать: в main.py замени
    from analyzer import analyze_startup
на
    from analyzer_free import analyze_startup
"""

import re
import logging
from typing import Dict, Optional

logger = logging.getLogger(__name__)

# Сигналы "стрельнул" — повышают оценку
BULLISH_PATTERNS = [
    (r"\$\d+[MmKk]",                    2.5),  # "$5M", "$30M"
    (r"series [abc]",                   2.5),  # Series A/B/C
    (r"seed round",                     1.5),
    (r"\byc\b|y combinator",            2.0),
    (r"a16z|sequoia|andreessen",        2.0),
    (r"#1 on product hunt",             1.5),
    (r"launch(ed|ing)",                 0.5),
    (r"\d{3,}k\s*users",               2.0),  # "500k users"
    (r"viral|trending|blew up",         1.5),
    (r"waitlist|sign.?up",              0.5),
    (r"open.?source",                   0.5),
    (r"ai|llm|gpt|ml\b",               0.3),
]

# Категории по ключевым словам
CATEGORIES = {
    "AI":        ["ai", "llm", "gpt", "claude", "gemini", "ml", "neural", "model"],
    "Fintech":   ["fintech", "payment", "banking", "crypto", "defi", "wallet", "finance"],
    "Dev Tools": ["developer", "devtool", "ide", "cli", "api", "sdk", "github", "code"],
    "SaaS":      ["saas", "b2b", "enterprise", "dashboard", "analytics", "crm"],
    "Consumer":  ["app", "consumer", "social", "marketplace", "e-commerce"],
    "Health":    ["health", "medical", "wellness", "fitness", "biotech"],
}

# Источники с весами
SOURCE_BONUS = {
    "Hacker News":  0.5,
    "Product Hunt": 0.5,
    "TechCrunch":   1.0,   # если TC написал — уже сигнал
}


def _detect_category(text: str) -> str:
    text_low = text.lower()
    for cat, keywords in CATEGORIES.items():
        if any(kw in text_low for kw in keywords):
            return cat
    return "Other"


def _score(item: Dict) -> float:
    full_text = (
        (item.get("title", "") + " " + item.get("description", "")).lower()
    )
    score = 3.0  # base

    # Keyword signals
    for pattern, weight in BULLISH_PATTERNS:
        if re.search(pattern, full_text, re.IGNORECASE):
            score += weight

    # Upvotes bonus
    upvotes = item.get("upvotes", 0)
    if upvotes >= 500:
        score += 2.0
    elif upvotes >= 200:
        score += 1.0
    elif upvotes >= 100:
        score += 0.5

    # Source bonus
    source = item.get("source", "")
    for src, bonus in SOURCE_BONUS.items():
        if src in source:
            score += bonus
            break

    return min(round(score, 1), 10.0)


def _make_what(item: Dict) -> str:
    """Generate a simple 'what it does' from title + description."""
    desc = item.get("description", "").strip()
    if desc and len(desc) > 20:
        # First sentence of description
        first = re.split(r"[.!?]", desc)[0].strip()
        if len(first) > 10:
            return first[:120]
    return item.get("title", "")


def _make_why(item: Dict) -> str:
    """Extract the most impressive signal as the 'why it blew up'."""
    full = (item.get("title", "") + " " + item.get("description", "")).lower()

    if m := re.search(r"\$(\d+[MmKk])[^\w]", full):
        return f"Привлёк {m.group(1)} финансирования"
    if re.search(r"series [abc]", full, re.IGNORECASE):
        return "Поднял значительный раунд финансирования"
    if re.search(r"\byc\b|y combinator", full):
        return "Backed by Y Combinator"
    if re.search(r"a16z|sequoia|andreessen", full):
        return "Backed by top-tier VC"
    upvotes = item.get("upvotes", 0)
    if upvotes >= 300:
        return f"Завирусился — {upvotes} upvotes в сообществе"
    if re.search(r"\d{3,}k\s*users", full):
        return "Взрывной рост пользователей"
    if re.search(r"#1 on product hunt", full, re.IGNORECASE):
        return "#1 на Product Hunt сегодня"
    return "Активное обсуждение в tech-сообществе"


async def analyze_startup(item: Dict, api_key: str = "") -> Optional[Dict]:
    """Free heuristic analyzer — no API calls."""
    score = _score(item)
    return {
        "score":    score,
        "what":     _make_what(item),
        "why":      _make_why(item),
        "category": _detect_category(item.get("title", "") + " " + item.get("description", "")),
    }
