import httpx
import logging
from datetime import datetime, timezone
from typing import List, Dict

logger = logging.getLogger(__name__)

TG_API = "https://api.telegram.org/bot{token}/sendMessage"


async def send_digest(token: str, chat_id: str, startups: List[Dict]):
    """Send all startups in ONE single message."""
    date_str = datetime.now(timezone.utc).strftime("%d %b %Y")

    if not startups:
        await _send(token, chat_id,
                    f"📭 *Дайджест {date_str}*\n\nСегодня ничего нового не нашлось.")
        return

    lines = [f"🚀 *Стартап-дайджест {date_str}* — {len(startups)} новых\n"]

    for s in startups:
        analysis = s.get("analysis", {})
        score    = analysis.get("score", 0)
        what     = analysis.get("what", "")
        why      = analysis.get("why", "")
        category = analysis.get("category", "")

        emoji = "🔥" if score >= 8 else "⭐" if score >= 7 else "📌"

        lines.append(
            f"{emoji} *{_esc(s['title'])}* — {_esc(category)}\n"
            f"{_esc(what)}\n"
            f"_{_esc(why)}_\n"
            f"🔗 {s['url']}\n"
        )

    full_message = "\n".join(lines)

    # Telegram limit = 4096 chars. Split into chunks if needed.
    if len(full_message) <= 4096:
        await _send(token, chat_id, full_message)
    else:
        chunks, current, size = [], [], 0
        for block in lines:
            if size + len(block) > 4000 and current:
                await _send(token, chat_id, "\n".join(current))
                current, size = [], 0
            current.append(block)
            size += len(block)
        if current:
            await _send(token, chat_id, "\n".join(current))


async def _send(token: str, chat_id: str, text: str):
    url = TG_API.format(token=token)
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(url, json={
                "chat_id":                  chat_id,
                "text":                     text,
                "parse_mode":               "Markdown",
                "disable_web_page_preview": True,
            })
            data = resp.json()
            if not data.get("ok"):
                logger.error(f"TG error: {data}")
    except Exception as e:
        logger.error(f"TG send failed: {e}")


def _esc(text: str) -> str:
    for ch in ["_", "*", "[", "]", "`"]:
        text = text.replace(ch, f"\\{ch}")
    return text
